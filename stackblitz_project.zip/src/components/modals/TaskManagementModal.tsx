import React, { useState } from 'react';
import { X, Plus, Edit, Trash2, Clock, User, UserCheck } from 'lucide-react';
import { Task } from '../../types';

interface TaskManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  tasks: Task[];
  users: Record<string, { password: string; role: 'Admin' | 'Agent' }>;
  onAddTask: (task: Omit<Task, 'id'>) => void;
  onUpdateTask: (taskId: string, updates: Partial<Task>) => void;
  onDeleteTask: (taskId: string) => void;
}

const TaskManagementModal: React.FC<TaskManagementModalProps> = ({
  isOpen,
  onClose,
  tasks,
  users,
  onAddTask,
  onUpdateTask,
  onDeleteTask
}) => {
  const [newTask, setNewTask] = useState({
    title: '',
    primary: '',
    backup: '',
    occurrence: '2 hours once',
    category: 'Every 2 Hours'
  });
  const [editingTask, setEditingTask] = useState<string | null>(null);
  const [editData, setEditData] = useState<Partial<Task>>({});
  const [error, setError] = useState('');

  const agents = Object.keys(users).filter(username => users[username].role === 'Agent');

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newTask.title.trim() || !newTask.primary || !newTask.backup) {
      setError('All fields are required');
      return;
    }

    if (newTask.primary === newTask.backup) {
      setError('Primary and backup agents must be different');
      return;
    }

    const task: Omit<Task, 'id'> = {
      title: newTask.title,
      primary: newTask.primary,
      backup: newTask.backup,
      category: newTask.category,
      status: 'Pending',
      comment: '',
      lastUpdated: null,
      occurrence: newTask.occurrence
    };

    onAddTask(task);
    setNewTask({
      title: '',
      primary: '',
      backup: '',
      occurrence: '2 hours once',
      category: 'Every 2 Hours'
    });
    setError('');
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task.id);
    setEditData({
      title: task.title,
      primary: task.primary,
      backup: task.backup,
      occurrence: task.occurrence,
      category: task.category
    });
  };

  const handleUpdateTask = () => {
    if (!editingTask || !editData.title?.trim() || !editData.primary || !editData.backup) {
      setError('All fields are required');
      return;
    }

    if (editData.primary === editData.backup) {
      setError('Primary and backup agents must be different');
      return;
    }

    onUpdateTask(editingTask, editData);
    setEditingTask(null);
    setEditData({});
    setError('');
  };

  const handleDeleteTask = (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (task && confirm(`Are you sure you want to delete task "${task.title}"?`)) {
      onDeleteTask(taskId);
    }
  };

  const handleOccurrenceChange = (occurrence: string, isEdit = false) => {
    const categoryMap: Record<string, string> = {
      '2 hours once': 'Every 2 Hours',
      'Daily': 'Daily',
      'Monthly': 'Monthly'
    };

    if (isEdit) {
      setEditData(prev => ({
        ...prev,
        occurrence,
        category: categoryMap[occurrence]
      }));
    } else {
      setNewTask(prev => ({
        ...prev,
        occurrence,
        category: categoryMap[occurrence]
      }));
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Plus className="w-6 h-6 text-green-600 mr-2" />
              <h2 className="text-xl font-bold text-gray-900">Task Management</h2>
            </div>
            <button
              onClick={onClose}
              className="p-1 hover:bg-gray-100 rounded-full transition duration-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Add New Task */}
            <div className="bg-green-50 p-6 rounded-lg border border-green-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <Plus className="w-5 h-5 text-green-600 mr-2" />
                Add New Task
              </h3>
              
              <form onSubmit={handleAddTask} className="space-y-4">
                <div>
                  <label htmlFor="taskTitle" className="block text-sm font-medium text-gray-700 mb-2">
                    Task Title
                  </label>
                  <input
                    id="taskTitle"
                    type="text"
                    value={newTask.title}
                    onChange={(e) => setNewTask(prev => ({ ...prev, title: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="Enter task title"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="primaryAgent" className="block text-sm font-medium text-gray-700 mb-2">
                    Primary Agent
                  </label>
                  <select
                    id="primaryAgent"
                    value={newTask.primary}
                    onChange={(e) => setNewTask(prev => ({ ...prev, primary: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select primary agent</option>
                    {agents.map(agent => (
                      <option key={agent} value={agent}>{agent}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="backupAgent" className="block text-sm font-medium text-gray-700 mb-2">
                    Backup Agent
                  </label>
                  <select
                    id="backupAgent"
                    value={newTask.backup}
                    onChange={(e) => setNewTask(prev => ({ ...prev, backup: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select backup agent</option>
                    {agents.map(agent => (
                      <option key={agent} value={agent}>{agent}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="occurrence" className="block text-sm font-medium text-gray-700 mb-2">
                    Occurrence
                  </label>
                  <select
                    id="occurrence"
                    value={newTask.occurrence}
                    onChange={(e) => handleOccurrenceChange(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    required
                  >
                    <option value="2 hours once">Every 2 Hours</option>
                    <option value="Daily">Daily</option>
                    <option value="Monthly">Monthly</option>
                  </select>
                </div>

                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-600 px-3 py-2 rounded-lg text-sm">
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition duration-200"
                >
                  Add Task
                </button>
              </form>
            </div>

            {/* Existing Tasks */}
            <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Existing Tasks</h3>
              
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {tasks.map(task => (
                  <div key={task.id} className="bg-white p-4 rounded-lg border border-gray-200">
                    {editingTask === task.id ? (
                      <div className="space-y-3">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Task Title
                          </label>
                          <input
                            type="text"
                            value={editData.title || ''}
                            onChange={(e) => setEditData(prev => ({ ...prev, title: e.target.value }))}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Primary Agent
                            </label>
                            <select
                              value={editData.primary || ''}
                              onChange={(e) => setEditData(prev => ({ ...prev, primary: e.target.value }))}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                            >
                              {agents.map(agent => (
                                <option key={agent} value={agent}>{agent}</option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Backup Agent
                            </label>
                            <select
                              value={editData.backup || ''}
                              onChange={(e) => setEditData(prev => ({ ...prev, backup: e.target.value }))}
                              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                            >
                              {agents.map(agent => (
                                <option key={agent} value={agent}>{agent}</option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Occurrence
                          </label>
                          <select
                            value={editData.occurrence || ''}
                            onChange={(e) => handleOccurrenceChange(e.target.value, true)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                          >
                            <option value="2 hours once">Every 2 Hours</option>
                            <option value="Daily">Daily</option>
                            <option value="Monthly">Monthly</option>
                          </select>
                        </div>

                        <div className="flex space-x-2">
                          <button
                            onClick={handleUpdateTask}
                            className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700 transition duration-200"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingTask(null)}
                            className="px-3 py-1 bg-gray-600 text-white rounded text-sm hover:bg-gray-700 transition duration-200"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-gray-900 text-sm">{task.title}</h4>
                          <div className="flex space-x-1">
                            <button
                              onClick={() => handleEditTask(task)}
                              className="p-1 text-blue-600 hover:bg-blue-100 rounded transition duration-200"
                              title="Edit Task"
                            >
                              <Edit className="w-3 h-3" />
                            </button>
                            <button
                              onClick={() => handleDeleteTask(task.id)}
                              className="p-1 text-red-600 hover:bg-red-100 rounded transition duration-200"
                              title="Delete Task"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
                          <div className="flex items-center">
                            <User className="w-3 h-3 mr-1 text-blue-500" />
                            <span>{task.primary}</span>
                          </div>
                          <div className="flex items-center">
                            <UserCheck className="w-3 h-3 mr-1 text-green-500" />
                            <span>{task.backup}</span>
                          </div>
                          <div className="flex items-center col-span-2">
                            <Clock className="w-3 h-3 mr-1 text-purple-500" />
                            <span>{task.occurrence}</span>
                          </div>
                        </div>
                        
                        <div className="mt-2">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            task.status === 'Done' ? 'bg-green-100 text-green-800' :
                            task.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {task.status}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-6">
            <button
              onClick={onClose}
              className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition duration-200"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskManagementModal;