export interface User {
  password: string;
  role: 'Admin' | 'Agent';
}

export interface Task {
  id: string;
  title: string;
  primary: string;
  backup: string;
  category: string;
  status: 'Pending' | 'Done' | 'Delayed';
  comment: string;
  lastUpdated: string | null;
  occurrence: string;
}

export interface Holiday {
  date: string;
  name: string;
}

export interface CurrentUser {
  username: string;
  role: 'Admin' | 'Agent';
}