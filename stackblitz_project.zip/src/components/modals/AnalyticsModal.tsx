import React, { useState, useEffect } from 'react';
import { X, TrendingUp, Users, Clock, Target, Brain, AlertTriangle, Lightbulb, Zap } from 'lucide-react';
import { Task, CurrentUser } from '../../types';
import { aiService, PerformanceMetrics, AIInsight } from '../../services/aiService';

interface AnalyticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  tasks: Task[];
  currentUser: CurrentUser;
  users: Record<string, any>;
}

const AnalyticsModal: React.FC<AnalyticsModalProps> = ({
  isOpen,
  onClose,
  tasks,
  currentUser,
  users
}) => {
  const [metrics, setMetrics] = useState<PerformanceMetrics | null>(null);
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [selectedTab, setSelectedTab] = useState<'overview' | 'insights' | 'suggestions'>('overview');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen) {
      generateAnalytics();
    }
  }, [isOpen, tasks]);

  const generateAnalytics = async () => {
    setLoading(true);
    
    // Simulate AI processing time
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const userMetrics = currentUser.role === 'Admin' 
      ? aiService.generatePerformanceMetrics(tasks)
      : aiService.generatePerformanceMetrics(tasks, currentUser.username);
    
    const aiInsights = aiService.generateInsights(tasks, users);
    
    setMetrics(userMetrics);
    setInsights(aiInsights);
    setLoading(false);
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-red-500" />;
      case 'suggestion':
        return <Lightbulb className="w-5 h-5 text-yellow-500" />;
      case 'optimization':
        return <Zap className="w-5 h-5 text-blue-500" />;
      default:
        return <Brain className="w-5 h-5 text-purple-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'border-red-200 bg-red-50';
      case 'medium':
        return 'border-yellow-200 bg-yellow-50';
      case 'low':
        return 'border-green-200 bg-green-50';
      default:
        return 'border-gray-200 bg-gray-50';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Brain className="w-6 h-6 text-purple-600 mr-2" />
              <h2 className="text-xl font-bold text-gray-900">AI Analytics Dashboard</h2>
            </div>
            <button
              onClick={onClose}
              className="p-1 hover:bg-gray-100 rounded-full transition duration-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tab Navigation */}
          <div className="flex space-x-1 mb-6 bg-gray-100 rounded-lg p-1">
            {[
              { id: 'overview', label: 'Performance Overview', icon: TrendingUp },
              { id: 'insights', label: 'AI Insights', icon: Brain },
              { id: 'suggestions', label: 'Recommendations', icon: Lightbulb }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id as any)}
                className={`flex items-center px-4 py-2 rounded-md transition-colors ${
                  selectedTab === tab.id
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <tab.icon className="w-4 h-4 mr-2" />
                {tab.label}
              </button>
            ))}
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
              <span className="ml-3 text-gray-600">Analyzing data with AI...</span>
            </div>
          ) : (
            <>
              {/* Overview Tab */}
              {selectedTab === 'overview' && metrics && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                      <div className="flex items-center">
                        <Target className="w-8 h-8 text-blue-600 mr-3" />
                        <div>
                          <p className="text-sm text-blue-600 font-medium">Completion Rate</p>
                          <p className="text-2xl font-bold text-blue-900">
                            {Math.round(metrics.completionRate)}%
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                      <div className="flex items-center">
                        <Clock className="w-8 h-8 text-green-600 mr-3" />
                        <div>
                          <p className="text-sm text-green-600 font-medium">Avg Response</p>
                          <p className="text-2xl font-bold text-green-900">
                            {metrics.averageResponseTime}m
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                      <div className="flex items-center">
                        <AlertTriangle className="w-8 h-8 text-red-600 mr-3" />
                        <div>
                          <p className="text-sm text-red-600 font-medium">Overdue Tasks</p>
                          <p className="text-2xl font-bold text-red-900">
                            {metrics.overdueCount}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                      <div className="flex items-center">
                        <TrendingUp className="w-8 h-8 text-purple-600 mr-3" />
                        <div>
                          <p className="text-sm text-purple-600 font-medium">Efficiency</p>
                          <p className="text-2xl font-bold text-purple-900">
                            {Math.round(metrics.efficiency)}%
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Trend Charts */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="bg-white p-4 rounded-lg border border-gray-200">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Daily Performance Trend</h3>
                      <div className="flex items-end space-x-2 h-32">
                        {metrics.trends.daily.map((value, index) => (
                          <div key={index} className="flex-1 flex flex-col items-center">
                            <div
                              className="w-full bg-blue-500 rounded-t"
                              style={{ height: `${value}%` }}
                            ></div>
                            <span className="text-xs text-gray-500 mt-1">D{index + 1}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-gray-200">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Weekly Performance Trend</h3>
                      <div className="flex items-end space-x-2 h-32">
                        {metrics.trends.weekly.map((value, index) => (
                          <div key={index} className="flex-1 flex flex-col items-center">
                            <div
                              className="w-full bg-green-500 rounded-t"
                              style={{ height: `${value}%` }}
                            ></div>
                            <span className="text-xs text-gray-500 mt-1">W{index + 1}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Insights Tab */}
              {selectedTab === 'insights' && (
                <div className="space-y-4">
                  {insights.length === 0 ? (
                    <div className="text-center py-8">
                      <Brain className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500">No insights available at this time.</p>
                    </div>
                  ) : (
                    insights.map((insight, index) => (
                      <div
                        key={index}
                        className={`p-4 rounded-lg border ${getPriorityColor(insight.priority)}`}
                      >
                        <div className="flex items-start space-x-3">
                          {getInsightIcon(insight.type)}
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-2">
                              <h3 className="font-semibold text-gray-900">{insight.title}</h3>
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                insight.priority === 'high' ? 'bg-red-100 text-red-800' :
                                insight.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-green-100 text-green-800'
                              }`}>
                                {insight.priority.toUpperCase()}
                              </span>
                            </div>
                            <p className="text-gray-700 text-sm">{insight.description}</p>
                            {insight.actionable && (
                              <div className="mt-2">
                                <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                                  Take Action →
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* Suggestions Tab */}
              {selectedTab === 'suggestions' && (
                <div className="space-y-6">
                  <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-6 rounded-lg border border-purple-200">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                      <Zap className="w-5 h-5 text-purple-600 mr-2" />
                      AI-Powered Recommendations
                    </h3>
                    
                    <div className="space-y-4">
                      <div className="bg-white p-4 rounded-lg border border-gray-200">
                        <h4 className="font-medium text-gray-900 mb-2">Task Redistribution</h4>
                        <p className="text-sm text-gray-600 mb-3">
                          Based on current workload analysis, consider redistributing tasks for better balance.
                        </p>
                        <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition duration-200 text-sm">
                          View Suggestions
                        </button>
                      </div>

                      <div className="bg-white p-4 rounded-lg border border-gray-200">
                        <h4 className="font-medium text-gray-900 mb-2">Automation Opportunities</h4>
                        <p className="text-sm text-gray-600 mb-3">
                          Identified 3 repetitive tasks that could benefit from automation.
                        </p>
                        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200 text-sm">
                          Explore Automation
                        </button>
                      </div>

                      <div className="bg-white p-4 rounded-lg border border-gray-200">
                        <h4 className="font-medium text-gray-900 mb-2">Performance Optimization</h4>
                        <p className="text-sm text-gray-600 mb-3">
                          Optimize task scheduling to improve overall team efficiency by 15%.
                        </p>
                        <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition duration-200 text-sm">
                          Apply Optimization
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* User Performance Breakdown */}
                  {currentUser.role === 'Admin' && (
                    <div className="bg-white p-4 rounded-lg border border-gray-200">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                        <Users className="w-5 h-5 text-blue-600 mr-2" />
                        Team Performance Analysis
                      </h3>
                      
                      <div className="space-y-3">
                        {Object.keys(users)
                          .filter(username => users[username].role === 'Agent')
                          .map(username => {
                            const userTasks = tasks.filter(t => 
                              t.primary === username || t.backup === username
                            );
                            const completedTasks = userTasks.filter(t => t.status === 'Done').length;
                            const completionRate = userTasks.length > 0 
                              ? (completedTasks / userTasks.length) * 100 
                              : 0;

                            return (
                              <div key={username} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                <div>
                                  <p className="font-medium text-gray-900">{username}</p>
                                  <p className="text-sm text-gray-600">
                                    {userTasks.length} tasks assigned
                                  </p>
                                </div>
                                <div className="text-right">
                                  <p className="font-semibold text-gray-900">
                                    {Math.round(completionRate)}%
                                  </p>
                                  <div className="w-20 bg-gray-200 rounded-full h-2">
                                    <div
                                      className="bg-blue-600 h-2 rounded-full"
                                      style={{ width: `${completionRate}%` }}
                                    ></div>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          <div className="flex justify-end pt-6">
            <button
              onClick={onClose}
              className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition duration-200"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsModal;