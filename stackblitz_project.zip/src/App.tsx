import React, { useState, useCallback, useEffect } from 'react';
import LoginForm from './components/LoginForm';
import Header from './components/Header';
import TasksDisplay from './components/TasksDisplay';
import HolidayList from './components/HolidayList';
import TaskModal from './components/modals/TaskModal';
import CalendarModal from './components/modals/CalendarModal';
import HolidayModal from './components/modals/HolidayModal';
import ReminderSettingsModal from './components/modals/ReminderSettingsModal';
import AnalyticsModal from './components/modals/AnalyticsModal';
import UserManagementModal from './components/modals/UserManagementModal';
import TaskManagementModal from './components/modals/TaskManagementModal';
import RealTimeNotification from './components/RealTimeNotification';
import { users as initialUsers, initialTasks, initialHolidays } from './data/initialData';
import { isWeekend, isHoliday, formatDateTime } from './utils/dateUtils';
import { useAutoRefresh } from './hooks/useAutoRefresh';
import { dataService } from './services/dataService';
import { reminderService } from './services/reminderService';
import { CurrentUser, Task, Holiday } from './types';

function App() {
  const [currentUser, setCurrentUser] = useState<CurrentUser | null>(null);
  const [users, setUsers] = useState(initialUsers);
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [holidays, setHolidays] = useState<Holiday[]>(initialHolidays);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isCalendarModalOpen, setIsCalendarModalOpen] = useState(false);
  const [isHolidayModalOpen, setIsHolidayModalOpen] = useState(false);
  const [isReminderSettingsOpen, setIsReminderSettingsOpen] = useState(false);
  const [isAnalyticsOpen, setIsAnalyticsOpen] = useState(false);
  const [isUserManagementOpen, setIsUserManagementOpen] = useState(false);
  const [isTaskManagementOpen, setIsTaskManagementOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState(true);
  const [refreshInterval] = useState(30000); // 30 seconds
  const [notifications, setNotifications] = useState<Array<{
    id: string;
    type: 'success' | 'warning' | 'info';
    message: string;
    timestamp: Date;
  }>>([]);
  const [automaticRemindersEnabled, setAutomaticRemindersEnabled] = useState(false);

  const addNotification = (type: 'success' | 'warning' | 'info', message: string) => {
    const notification = {
      id: Date.now().toString(),
      type,
      message,
      timestamp: new Date()
    };
    setNotifications(prev => [...prev, notification]);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== notification.id));
    }, 5000);
  };

  const dismissNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  // Auto-refresh functionality
  const handleRefresh = useCallback(async () => {
    if (!currentUser) return;
    
    setIsRefreshing(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Check for updates from the data service
    const hasUpdates = dataService.checkForUpdates();
    
    if (hasUpdates) {
      // In a real app, you would fetch fresh data from the server here
      addNotification('info', 'Data refreshed from server');
      console.log('Data updated from server');
    }
    
    setLastUpdate(new Date());
    setIsRefreshing(false);
  }, [currentUser]);

  const { stopRefresh, startRefresh } = useAutoRefresh({
    interval: refreshInterval,
    enabled: autoRefreshEnabled && !!currentUser,
    onRefresh: handleRefresh
  });

  // Subscribe to real-time updates
  useEffect(() => {
    const unsubscribe = dataService.subscribe(() => {
      addNotification('success', 'Real-time update received');
      setLastUpdate(new Date());
      // Force re-render by updating state
      setTasks(prevTasks => [...prevTasks]);
      setHolidays(prevHolidays => [...prevHolidays]);
    });

    return unsubscribe;
  }, []);

  // Initialize reminder service and request notification permission
  useEffect(() => {
    if (currentUser) {
      reminderService.requestNotificationPermission();
      
      // Start automatic reminders for admin users
      if (currentUser.role === 'Admin' && !automaticRemindersEnabled) {
        reminderService.startAutomaticReminders(tasks, users, () => {
          addNotification('info', 'Automatic reminder sent');
        });
        setAutomaticRemindersEnabled(true);
      }

      // Schedule daily summary
      reminderService.scheduleDailySummary(tasks);
    }

    return () => {
      if (automaticRemindersEnabled) {
        reminderService.stopAutomaticReminders();
        setAutomaticRemindersEnabled(false);
      }
    };
  }, [currentUser, tasks]);
  const toggleAutoRefresh = () => {
    setAutoRefreshEnabled(prev => {
      const newValue = !prev;
      if (newValue) {
        startRefresh();
      } else {
        stopRefresh();
      }
      return newValue;
    });
  };

  const handleLogin = (user: CurrentUser) => {
    setCurrentUser(user);
    setLastUpdate(new Date());
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setAutoRefreshEnabled(false);
    setAutomaticRemindersEnabled(false);
    stopRefresh();
    reminderService.stopAutomaticReminders();
  };

  const handleTaskClick = (task: Task) => {
    const today = new Date();
    if (isHoliday(today, holidays) || isWeekend(today)) {
      alert('Today is a holiday or weekend. Task update not allowed.');
      return;
    }

    if (currentUser?.role === 'Agent') {
      if (task.primary !== currentUser.username && task.backup !== currentUser.username) {
        alert('You can only update your assigned or backup tasks.');
        return;
      }
    }

    setSelectedTask(task);
    setIsTaskModalOpen(true);
  };

  const handleTaskSave = (taskId: string, status: string, comment: string) => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === taskId
          ? {
              ...task,
              status: status as 'Pending' | 'Done' | 'Delayed',
              comment,
              lastUpdated: formatDateTime(new Date())
            }
          : task
      )
    );
    
    // Notify data service of the update
    dataService.updateTask(taskId, { status: status as any, comment });
    addNotification('success', 'Task status updated successfully');
  };

  const handleAddUser = (username: string, password: string, role: 'Admin' | 'Agent') => {
    setUsers(prevUsers => ({
      ...prevUsers,
      [username]: { password, role }
    }));
    dataService.addUser(username, { password, role });
    addNotification('success', `User ${username} added successfully`);
  };

  const handleUpdateUser = (username: string, updates: { password?: string; role?: 'Admin' | 'Agent' }) => {
    setUsers(prevUsers => ({
      ...prevUsers,
      [username]: { ...prevUsers[username], ...updates }
    }));
    addNotification('success', `User ${username} updated successfully`);
  };

  const handleDeleteUser = (username: string) => {
    setUsers(prevUsers => {
      const newUsers = { ...prevUsers };
      delete newUsers[username];
      return newUsers;
    });
    addNotification('warning', `User ${username} deleted`);
  };

  const handleAddTask = (taskData: Omit<Task, 'id'>) => {
    const newTask: Task = {
      ...taskData,
      id: Date.now().toString()
    };
    
    setTasks(prevTasks => [...prevTasks, newTask]);
    dataService.addTask(newTask);
    addNotification('success', 'New task added successfully');
  };

  const handleUpdateTask = (taskId: string, updates: Partial<Task>) => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === taskId ? { ...task, ...updates } : task
      )
    );
    addNotification('success', 'Task updated successfully');
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks(prevTasks => prevTasks.filter(task => task.id !== taskId));
    addNotification('warning', 'Task deleted');
  };

  const handleAddHoliday = (holiday: Holiday) => {
    setHolidays(prevHolidays => [...prevHolidays, holiday]);
    dataService.addHoliday(holiday);
    addNotification('success', `Holiday "${holiday.name}" added`);
  };

  const handleDeleteHoliday = (index: number) => {
    if (confirm('Are you sure you want to delete this holiday?')) {
      const holidayName = holidays[index]?.name;
      setHolidays(prevHolidays => prevHolidays.filter((_, i) => i !== index));
      dataService.deleteHoliday(index);
      addNotification('warning', `Holiday "${holidayName}" deleted`);
    }
  };

  const handleSendReminders = () => {
    const overdueTasks = reminderService.getOverdueTasks(tasks);
    const pendingTasks = reminderService.getPendingTasks(tasks);
    
    if (overdueTasks.length === 0) {
      if (pendingTasks.length === 0) {
        addNotification('info', 'No overdue or pending tasks found');
        alert('No overdue or pending tasks!');
        return;
      }
      
      // Send reminders for pending tasks
      reminderService.sendBulkReminder(pendingTasks, 'pending').then(success => {
        if (success) {
          addNotification('success', `Reminders sent for ${pendingTasks.length} pending tasks`);
          alert(`Reminder sent to agents for ${pendingTasks.length} pending tasks.`);
        } else {
          addNotification('warning', 'Failed to send reminders');
        }
      });
      return;
    }
    
    // Send urgent reminders for overdue tasks
    reminderService.sendBulkReminder(overdueTasks, 'overdue').then(success => {
      if (success) {
        addNotification('success', `Urgent reminders sent for ${overdueTasks.length} overdue tasks`);
        alert(`Urgent reminder sent to agents for ${overdueTasks.length} overdue tasks.`);
        
        // Also send individual reminders
        reminderService.sendIndividualReminders(overdueTasks, users);
      } else {
        addNotification('warning', 'Failed to send reminders');
      }
    });
  };

  if (!currentUser) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      <Header
        currentUser={currentUser}
        onLogout={handleLogout}
        onShowCalendar={() => setIsCalendarModalOpen(true)}
        onManageHolidays={() => setIsHolidayModalOpen(true)}
        onSendReminders={handleSendReminders}
        onReminderSettings={() => setIsReminderSettingsOpen(true)}
        onShowAnalytics={() => setIsAnalyticsOpen(true)}
        onManageUsers={() => setIsUserManagementOpen(true)}
        onManageTasks={() => setIsTaskManagementOpen(true)}
        isRefreshing={isRefreshing}
        lastUpdate={lastUpdate}
        autoRefreshEnabled={autoRefreshEnabled}
        onToggleAutoRefresh={toggleAutoRefresh}
        refreshInterval={refreshInterval}
      />

      <TasksDisplay
        tasks={tasks}
        currentUser={currentUser}
        onTaskClick={handleTaskClick}
      />

      {currentUser.role === 'Agent' && (
        <HolidayList holidays={holidays} />
      )}

      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        task={selectedTask}
        onSave={handleTaskSave}
      />

      <CalendarModal
        isOpen={isCalendarModalOpen}
        onClose={() => setIsCalendarModalOpen(false)}
        tasks={tasks}
        currentUser={currentUser}
      />

      <HolidayModal
        isOpen={isHolidayModalOpen}
        onClose={() => setIsHolidayModalOpen(false)}
        holidays={holidays}
        onAddHoliday={handleAddHoliday}
        onDeleteHoliday={handleDeleteHoliday}
      />

      <ReminderSettingsModal
        isOpen={isReminderSettingsOpen}
        onClose={() => setIsReminderSettingsOpen(false)}
      />

      <AnalyticsModal
        isOpen={isAnalyticsOpen}
        onClose={() => setIsAnalyticsOpen(false)}
        tasks={tasks}
        currentUser={currentUser}
        users={users}
      />

      <UserManagementModal
        isOpen={isUserManagementOpen}
        onClose={() => setIsUserManagementOpen(false)}
        users={users}
        onAddUser={handleAddUser}
        onUpdateUser={handleUpdateUser}
        onDeleteUser={handleDeleteUser}
      />

      <TaskManagementModal
        isOpen={isTaskManagementOpen}
        onClose={() => setIsTaskManagementOpen(false)}
        tasks={tasks}
        users={users}
        onAddTask={handleAddTask}
        onUpdateTask={handleUpdateTask}
        onDeleteTask={handleDeleteTask}
      />

      <RealTimeNotification
        notifications={notifications}
        onDismiss={dismissNotification}
      />
    </div>
  );
}

export default App;