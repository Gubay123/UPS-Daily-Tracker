import React, { useState, useEffect } from 'react';
import { RefreshCw, Wifi, WifiOff } from 'lucide-react';

interface AutoRefreshIndicatorProps {
  isRefreshing: boolean;
  lastUpdate: Date | null;
  isEnabled: boolean;
  onToggle: () => void;
  refreshInterval: number;
}

const AutoRefreshIndicator: React.FC<AutoRefreshIndicatorProps> = ({
  isRefreshing,
  lastUpdate,
  isEnabled,
  onToggle,
  refreshInterval
}) => {
  const [timeUntilNext, setTimeUntilNext] = useState(refreshInterval / 1000);

  useEffect(() => {
    if (!isEnabled) return;

    const interval = setInterval(() => {
      setTimeUntilNext(prev => {
        if (prev <= 1) {
          return refreshInterval / 1000;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isEnabled, refreshInterval]);

  useEffect(() => {
    if (isRefreshing) {
      setTimeUntilNext(refreshInterval / 1000);
    }
  }, [isRefreshing, refreshInterval]);

  return (
    <div className="flex items-center space-x-2 text-sm">
      <button
        onClick={onToggle}
        className={`flex items-center space-x-1 px-2 py-1 rounded-lg transition-colors ${
          isEnabled 
            ? 'bg-green-100 text-green-700 hover:bg-green-200' 
            : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
        }`}
        title={isEnabled ? 'Auto-refresh enabled' : 'Auto-refresh disabled'}
      >
        {isEnabled ? <Wifi className="w-4 h-4" /> : <WifiOff className="w-4 h-4" />}
        <span>{isEnabled ? 'Live' : 'Offline'}</span>
      </button>

      {isEnabled && (
        <div className="flex items-center space-x-1 text-gray-600">
          <RefreshCw 
            className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} 
          />
          <span>
            {isRefreshing ? 'Refreshing...' : `${timeUntilNext}s`}
          </span>
        </div>
      )}

      {lastUpdate && (
        <div className="text-xs text-gray-500">
          Last: {lastUpdate.toLocaleTimeString()}
        </div>
      )}
    </div>
  );
};

export default AutoRefreshIndicator;