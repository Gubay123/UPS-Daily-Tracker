import { Task, Holiday, User } from '../types';

// Simulated real-time data service
class DataService {
  private static instance: DataService;
  private listeners: Set<() => void> = new Set();
  private lastUpdate: number = Date.now();

  static getInstance(): DataService {
    if (!DataService.instance) {
      DataService.instance = new DataService();
    }
    return DataService.instance;
  }

  // Subscribe to data changes
  subscribe(callback: () => void): () => void {
    this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }

  // Notify all listeners of data changes
  private notifyListeners(): void {
    this.lastUpdate = Date.now();
    this.listeners.forEach(callback => callback());
  }

  // Simulate checking for updates from server
  checkForUpdates(): boolean {
    // In a real app, this would check with the server
    // For demo, we'll randomly simulate updates
    const shouldUpdate = Math.random() < 0.1; // 10% chance of update
    if (shouldUpdate) {
      this.notifyListeners();
    }
    return shouldUpdate;
  }

  // Update task and notify listeners
  updateTask(taskId: string, updates: Partial<Task>): void {
    // In a real app, this would send to server
    this.notifyListeners();
  }

  // Add holiday and notify listeners
  addHoliday(holiday: Holiday): void {
    // In a real app, this would send to server
    this.notifyListeners();
  }

  // Delete holiday and notify listeners
  deleteHoliday(index: number): void {
    // In a real app, this would send to server
    this.notifyListeners();
  }

  // Add user and notify listeners
  addUser(username: string, user: User): void {
    // In a real app, this would send to server
    this.notifyListeners();
  }

  // Add task and notify listeners
  addTask(task: Task): void {
    // In a real app, this would send to server
    this.notifyListeners();
  }

  getLastUpdate(): number {
    return this.lastUpdate;
  }
}

export const dataService = DataService.getInstance();