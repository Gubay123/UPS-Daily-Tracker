import React from 'react';
import TaskCard from './TaskCard';
import { Task, CurrentUser } from '../types';

interface TasksDisplayProps {
  tasks: Task[];
  currentUser: CurrentUser;
  onTaskClick: (task: Task) => void;
}

const TasksDisplay: React.FC<TasksDisplayProps> = ({ tasks, currentUser, onTaskClick }) => {
  const categories = ['2 hours once', 'Daily', 'Monthly'];

  const getFilteredTasks = (category: string) => {
    return tasks.filter(task => {
      const matchesCategory = task.occurrence.toLowerCase() === category.toLowerCase();
      const hasAccess = currentUser.role === 'Admin' || 
                       task.primary === currentUser.username || 
                       task.backup === currentUser.username;
      return matchesCategory && hasAccess;
    });
  };

  const getCategoryTitle = (category: string) => {
    switch (category) {
      case '2 hours once':
        return 'Every 2 Hours';
      case 'Daily':
        return 'Daily Tasks';
      case 'Monthly':
        return 'Monthly Tasks';
      default:
        return category;
    }
  };

  return (
    <div className="p-6 space-y-8">
      {categories.map(category => {
        const filteredTasks = getFilteredTasks(category);
        
        if (filteredTasks.length === 0) return null;

        return (
          <div key={category} className="space-y-4">
            <h2 className="text-2xl font-bold text-blue-800">
              {getCategoryTitle(category)}
            </h2>
            
            <div className="flex overflow-x-auto gap-4 pb-4">
              {filteredTasks.map(task => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onClick={() => onTaskClick(task)}
                />
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default TasksDisplay;