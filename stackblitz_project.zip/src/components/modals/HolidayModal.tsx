import React, { useState } from 'react';
import { X, Plus, Trash2 } from 'lucide-react';
import { Holiday } from '../../types';
import { isWeekend } from '../../utils/dateUtils';

interface HolidayModalProps {
  isOpen: boolean;
  onClose: () => void;
  holidays: Holiday[];
  onAddHoliday: (holiday: Holiday) => void;
  onDeleteHoliday: (index: number) => void;
}

const HolidayModal: React.FC<HolidayModalProps> = ({
  isOpen,
  onClose,
  holidays,
  onAddHoliday,
  onDeleteHoliday
}) => {
  const [holidayDate, setHolidayDate] = useState('');
  const [holidayName, setHolidayName] = useState('');
  const [error, setError] = useState('');

  const handleAddHoliday = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!holidayDate.trim() || !holidayName.trim()) {
      setError('Both date and name are required');
      return;
    }

    const date = new Date(holidayDate);
    if (isWeekend(date)) {
      setError('Cannot add holiday on fixed weekend (Saturday or Sunday)');
      return;
    }

    if (holidays.find(h => h.date === holidayDate)) {
      setError('Holiday for this date already exists');
      return;
    }

    onAddHoliday({ date: holidayDate, name: holidayName });
    setHolidayDate('');
    setHolidayName('');
    setError('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-md w-full max-h-[80vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Manage Holidays</h2>
            <button
              onClick={onClose}
              className="p-1 hover:bg-gray-100 rounded-full transition duration-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleAddHoliday} className="space-y-4 mb-6">
            <div>
              <label htmlFor="holidayDate" className="block text-sm font-medium text-gray-700 mb-2">
                Holiday Date
              </label>
              <input
                id="holidayDate"
                type="date"
                value={holidayDate}
                onChange={(e) => setHolidayDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>

            <div>
              <label htmlFor="holidayName" className="block text-sm font-medium text-gray-700 mb-2">
                Holiday Name
              </label>
              <input
                id="holidayName"
                type="text"
                value={holidayName}
                onChange={(e) => setHolidayName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="e.g., Independence Day"
                required
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-3 py-2 rounded-lg text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition duration-200 flex items-center justify-center"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Holiday
            </button>
          </form>

          <hr className="my-6" />

          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Existing Holidays</h3>
            {holidays.length === 0 ? (
              <p className="text-gray-500 italic">No holidays added yet.</p>
            ) : (
              <div className="space-y-2">
                {holidays
                  .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                  .map((holiday, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">{holiday.name}</p>
                        <p className="text-sm text-gray-600">{new Date(holiday.date).toLocaleDateString()}</p>
                      </div>
                      <button
                        onClick={() => onDeleteHoliday(index)}
                        className="p-2 text-red-600 hover:bg-red-100 rounded-lg transition duration-200"
                        title="Delete Holiday"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
              </div>
            )}
          </div>

          <div className="flex justify-end pt-6">
            <button
              onClick={onClose}
              className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition duration-200"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HolidayModal;