import React, { useState, useEffect } from 'react';
import { X, Bell, Mail, Clock, Settings } from 'lucide-react';
import { reminderService, ReminderSettings } from '../../services/reminderService';

interface ReminderSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ReminderSettingsModal: React.FC<ReminderSettingsModalProps> = ({
  isOpen,
  onClose
}) => {
  const [settings, setSettings] = useState<ReminderSettings>(reminderService.getSettings());
  const [notificationPermission, setNotificationPermission] = useState<string>('default');

  useEffect(() => {
    if (isOpen) {
      setSettings(reminderService.getSettings());
      setNotificationPermission(Notification.permission);
    }
  }, [isOpen]);

  const handleSaveSettings = () => {
    reminderService.updateSettings(settings);
    onClose();
  };

  const handleRequestNotificationPermission = async () => {
    const granted = await reminderService.requestNotificationPermission();
    setNotificationPermission(Notification.permission);
    if (granted) {
      setSettings(prev => ({ ...prev, browserNotificationsEnabled: true }));
    }
  };

  const handleTestNotification = () => {
    reminderService.showBrowserNotification(
      'Test Notification',
      'This is a test notification from UPS Contact Center'
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-md w-full max-h-[80vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Settings className="w-6 h-6 text-blue-600 mr-2" />
              <h2 className="text-xl font-bold text-gray-900">Reminder Settings</h2>
            </div>
            <button
              onClick={onClose}
              className="p-1 hover:bg-gray-100 rounded-full transition duration-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Email Notifications */}
            <div className="space-y-3">
              <div className="flex items-center">
                <Mail className="w-5 h-5 text-blue-600 mr-2" />
                <h3 className="text-lg font-semibold text-gray-900">Email Notifications</h3>
              </div>
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={settings.emailEnabled}
                  onChange={(e) => setSettings(prev => ({ ...prev, emailEnabled: e.target.checked }))}
                  className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <span className="text-gray-700">Enable email reminders</span>
              </label>
            </div>

            {/* Browser Notifications */}
            <div className="space-y-3">
              <div className="flex items-center">
                <Bell className="w-5 h-5 text-blue-600 mr-2" />
                <h3 className="text-lg font-semibold text-gray-900">Browser Notifications</h3>
              </div>
              
              {notificationPermission === 'denied' && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-3 py-2 rounded-lg text-sm">
                  Browser notifications are blocked. Please enable them in your browser settings.
                </div>
              )}

              {notificationPermission === 'default' && (
                <button
                  onClick={handleRequestNotificationPermission}
                  className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition duration-200"
                >
                  Enable Browser Notifications
                </button>
              )}

              {notificationPermission === 'granted' && (
                <div className="space-y-2">
                  <label className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={settings.browserNotificationsEnabled}
                      onChange={(e) => setSettings(prev => ({ ...prev, browserNotificationsEnabled: e.target.checked }))}
                      className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <span className="text-gray-700">Enable browser notifications</span>
                  </label>
                  <button
                    onClick={handleTestNotification}
                    className="text-sm text-blue-600 hover:text-blue-800 underline"
                  >
                    Test notification
                  </button>
                </div>
              )}
            </div>

            {/* Timing Settings */}
            <div className="space-y-3">
              <div className="flex items-center">
                <Clock className="w-5 h-5 text-blue-600 mr-2" />
                <h3 className="text-lg font-semibold text-gray-900">Timing Settings</h3>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reminder Interval (minutes)
                </label>
                <select
                  value={settings.reminderInterval}
                  onChange={(e) => setSettings(prev => ({ ...prev, reminderInterval: parseInt(e.target.value) }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value={15}>15 minutes</option>
                  <option value={30}>30 minutes</option>
                  <option value={60}>1 hour</option>
                  <option value={120}>2 hours</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Overdue Threshold (hours)
                </label>
                <select
                  value={settings.overdueThreshold}
                  onChange={(e) => setSettings(prev => ({ ...prev, overdueThreshold: parseInt(e.target.value) }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value={1}>1 hour</option>
                  <option value={2}>2 hours</option>
                  <option value={4}>4 hours</option>
                  <option value={8}>8 hours</option>
                  <option value={24}>24 hours</option>
                </select>
              </div>
            </div>

            {/* Current Status */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">Current Status</h4>
              <div className="space-y-1 text-sm text-gray-600">
                <p>Email: {settings.emailEnabled ? '✅ Enabled' : '❌ Disabled'}</p>
                <p>Browser: {settings.browserNotificationsEnabled && notificationPermission === 'granted' ? '✅ Enabled' : '❌ Disabled'}</p>
                <p>Interval: {settings.reminderInterval} minutes</p>
                <p>Overdue after: {settings.overdueThreshold} hours</p>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-6">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-800 transition duration-200"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveSettings}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200"
            >
              Save Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReminderSettingsModal;