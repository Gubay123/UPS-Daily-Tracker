import React, { useState, useEffect } from 'react';
import { Clock, User, UserCheck } from 'lucide-react';
import { Task } from '../types';

interface TaskCardProps {
  task: Task;
  onClick: () => void;
}

const TaskCard: React.FC<TaskCardProps> = ({ task, onClick }) => {
  const [isUpdated, setIsUpdated] = useState(false);

  // Show visual feedback when task is updated
  useEffect(() => {
    setIsUpdated(true);
    const timer = setTimeout(() => setIsUpdated(false), 1000);
    return () => clearTimeout(timer);
  }, [task.lastUpdated, task.status]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Done':
        return 'bg-green-500';
      case 'Pending':
        return 'bg-yellow-500';
      case 'Delayed':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div
      onClick={onClick}
      className={`flex-shrink-0 w-72 bg-white rounded-lg shadow-lg p-6 cursor-pointer hover:shadow-xl transition-all duration-200 hover:scale-105 border ${
        isUpdated ? 'border-blue-400 ring-2 ring-blue-200' : 'border-gray-100'
      }`}
    >
      <h3 className="font-semibold text-gray-900 mb-3 line-clamp-2 min-h-[3rem]">
        {task.title}
      </h3>
      
      <div className="space-y-2 mb-4">
        <div className="flex items-center text-sm text-gray-600">
          <User className="w-4 h-4 mr-2 text-blue-500" />
          <span className="font-medium">Primary:</span>
          <span className="ml-1">{task.primary}</span>
        </div>
        
        <div className="flex items-center text-sm text-gray-600">
          <UserCheck className="w-4 h-4 mr-2 text-green-500" />
          <span className="font-medium">Backup:</span>
          <span className="ml-1">{task.backup}</span>
        </div>
        
        <div className="flex items-center text-sm text-gray-600">
          <Clock className="w-4 h-4 mr-2 text-purple-500" />
          <span className="font-medium">Frequency:</span>
          <span className="ml-1">{task.occurrence}</span>
        </div>
      </div>
      
      <div className="flex items-center justify-between">
        <span className={`px-3 py-1 rounded-full text-white text-sm font-medium ${getStatusColor(task.status)}`}>
          {task.status}
          {isUpdated && (
            <span className="ml-1 inline-block w-2 h-2 bg-white rounded-full animate-pulse"></span>
          )}
        </span>
      </div>
      
      <div className="mt-3 text-xs text-gray-500">
        <span>Last Updated: {task.lastUpdated || 'Never'}</span>
      </div>
    </div>
  );
};

export default TaskCard;