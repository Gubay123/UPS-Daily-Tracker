import React, { useState } from 'react';
import { X, Calendar } from 'lucide-react';
import { Task, CurrentUser } from '../../types';

interface CalendarModalProps {
  isOpen: boolean;
  onClose: () => void;
  tasks: Task[];
  currentUser: CurrentUser;
}

const CalendarModal: React.FC<CalendarModalProps> = ({ isOpen, onClose, tasks, currentUser }) => {
  const [selectedDate, setSelectedDate] = useState('');

  const getTasksForDate = (date: string) => {
    if (!date) return [];
    
    const dateObj = new Date(date);
    
    return tasks.filter(task => {
      const hasAccess = currentUser.role === 'Admin' || 
                       task.primary === currentUser.username || 
                       task.backup === currentUser.username;
      
      if (!hasAccess) return false;

      const occurrence = task.occurrence.toLowerCase();
      if (occurrence === 'daily' || occurrence === '2 hours once') return true;
      if (occurrence === 'monthly') return dateObj.getDate() === 1;
      
      return false;
    });
  };

  const tasksForDate = getTasksForDate(selectedDate);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Calendar className="w-6 h-6 text-blue-600 mr-2" />
              <h2 className="text-xl font-bold text-gray-900">Tasks by Date</h2>
            </div>
            <button
              onClick={onClose}
              className="p-1 hover:bg-gray-100 rounded-full transition duration-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="mb-6">
            <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-2">
              Select Date
            </label>
            <input
              id="date"
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div className="space-y-4">
            {!selectedDate ? (
              <p className="text-gray-500 italic">Please select a date to view tasks.</p>
            ) : tasksForDate.length === 0 ? (
              <p className="text-gray-500 italic">No tasks scheduled for the selected date.</p>
            ) : (
              tasksForDate.map(task => (
                <div key={task.id} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                  <h3 className="font-semibold text-gray-900 mb-2">{task.title}</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                    <div>
                      <span className="font-medium">Primary:</span> {task.primary}
                    </div>
                    <div>
                      <span className="font-medium">Backup:</span> {task.backup}
                    </div>
                    <div>
                      <span className="font-medium">Status:</span>
                      <span className={`ml-2 px-2 py-1 rounded-full text-xs text-white ${
                        task.status === 'Done' ? 'bg-green-500' :
                        task.status === 'Pending' ? 'bg-yellow-500' :
                        'bg-red-500'
                      }`}>
                        {task.status}
                      </span>
                    </div>
                    <div>
                      <span className="font-medium">Last Updated:</span> {task.lastUpdated || 'Never'}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="flex justify-end pt-6">
            <button
              onClick={onClose}
              className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition duration-200"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalendarModal;