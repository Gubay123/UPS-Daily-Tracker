import { User, Task, Holiday } from '../types';

export const users: Record<string, User> = {
  Sayantan: { password: 'Welcome@1234', role: 'Admin' },
  Aishwarya: { password: 'agent123', role: 'Agent' },
  Reema: { password: 'agent123', role: 'Agent' },
  Yashwanth: { password: 'agent123', role: 'Agent' },
  Manohar: { password: 'agent123', role: 'Agent' },
  Bhagyashree: { password: 'agent123', role: 'Agent' },
  Harshali: { password: 'agent123', role: 'Agent' },
  Gaurav: { password: 'agent123', role: 'Agent' }
};

export const initialTasks: Task[] = [
  {
    id: '1',
    title: 'Requires Action/myHR requires action',
    primary: 'Aishwarya',
    backup: 'Manohar',
    category: 'Every 2 Hours',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: '2 hours once'
  },
  {
    id: '2',
    title: 'AHT',
    primary: 'Reema',
    backup: 'Yashwanth',
    category: 'Every 2 Hours',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: '2 hours once'
  },
  {
    id: '3',
    title: 'FCR',
    primary: 'Yashwanth',
    backup: 'Sayantan',
    category: 'Every 2 Hours',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: '2 hours once'
  },
  {
    id: '4',
    title: 'Drop calls',
    primary: 'Manohar',
    backup: 'Gaurav',
    category: 'Every 2 Hours',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: '2 hours once'
  },
  {
    id: '5',
    title: 'Survey v/s calls taken',
    primary: 'Yashwanth',
    backup: 'Sayantan',
    category: 'Every 2 Hours',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: '2 hours once'
  },
  {
    id: '6',
    title: 'Schedule Adherence',
    primary: 'Reema',
    backup: 'Bhagyashree',
    category: 'Daily',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: 'Daily'
  },
  {
    id: '7',
    title: 'Sub cat 2 blank report',
    primary: 'Sayantan',
    backup: 'Aishwarya',
    category: 'Daily',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: 'Daily'
  },
  {
    id: '8',
    title: 'No Assignment group',
    primary: 'Yashwanth',
    backup: 'Bhagyashree',
    category: 'Daily',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: 'Daily'
  },
  {
    id: '9',
    title: 'KB tagging',
    primary: 'Harshali',
    backup: 'Sayantan',
    category: 'Daily',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: 'Daily'
  },
  {
    id: '10',
    title: 'Global assignment',
    primary: 'Harshali',
    backup: 'Sayantan',
    category: 'Daily',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: 'Daily'
  },
  {
    id: '11',
    title: 'General Category',
    primary: 'Bhagyashree',
    backup: 'Reema',
    category: 'Daily',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: 'Daily'
  },
  {
    id: '12',
    title: 'Variance',
    primary: 'Sayantan',
    backup: 'Yashwanth',
    category: 'Daily',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: 'Daily'
  },
  {
    id: '13',
    title: 'On-hold',
    primary: 'Yashwanth',
    backup: 'Sayantan',
    category: 'Daily',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: 'Daily'
  },
  {
    id: '14',
    title: 'Payroll T&C report',
    primary: 'Sayantan',
    backup: 'Yashwanth',
    category: 'Monthly',
    status: 'Pending',
    comment: '',
    lastUpdated: null,
    occurrence: 'Monthly'
  }
];

export const initialHolidays: Holiday[] = [];