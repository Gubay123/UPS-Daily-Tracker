export const isLoginAllowed = (): boolean => {
  const now = new Date();
  const hours = now.getHours();
  const minutes = now.getMinutes();

  // Allowed from 18:30 (6:30 PM) to 23:59 OR 00:00 to 11:00 AM
  return (hours > 18 || (hours === 18 && minutes >= 30)) || (hours < 11);
};

export const isWeekend = (date: Date): boolean => {
  const day = date.getDay();
  return day === 6 || day === 0; // Saturday=6, Sunday=0
};

export const isHoliday = (date: Date, holidays: Array<{ date: string; name: string }>): boolean => {
  const dateString = date.toISOString().split('T')[0];
  return holidays.some(h => h.date === dateString);
};

export const formatDateTime = (date: Date): string => {
  return date.toLocaleString('en-IN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });
};