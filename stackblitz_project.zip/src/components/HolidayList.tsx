import React from 'react';
import { Calendar } from 'lucide-react';
import { Holiday } from '../types';

interface HolidayListProps {
  holidays: Holiday[];
}

const HolidayList: React.FC<HolidayListProps> = ({ holidays }) => {
  const sortedHolidays = [...holidays].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="max-w-2xl mx-auto mt-8 bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center mb-4">
        <Calendar className="w-6 h-6 text-blue-600 mr-2" />
        <h3 className="text-xl font-bold text-gray-900">Upcoming Holidays</h3>
      </div>
      
      {sortedHolidays.length === 0 ? (
        <p className="text-gray-500 italic">No holidays scheduled.</p>
      ) : (
        <div className="space-y-3">
          {sortedHolidays.map((holiday, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div>
                <p className="font-semibold text-gray-900">{holiday.name}</p>
                <p className="text-sm text-gray-600">{new Date(holiday.date).toLocaleDateString()}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HolidayList;