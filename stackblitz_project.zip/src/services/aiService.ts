import { Task, CurrentUser } from '../types';

export interface TaskAnalysis {
  riskScore: number;
  recommendations: string[];
  predictedCompletion: string;
  workloadBalance: number;
}

export interface PerformanceMetrics {
  completionRate: number;
  averageResponseTime: number;
  overdueCount: number;
  efficiency: number;
  trends: {
    daily: number[];
    weekly: number[];
  };
}

export interface AIInsight {
  type: 'warning' | 'suggestion' | 'optimization';
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  actionable: boolean;
}

class AIService {
  private static instance: AIService;

  static getInstance(): AIService {
    if (!AIService.instance) {
      AIService.instance = new AIService();
    }
    return AIService.instance;
  }

  // Analyze task completion patterns and predict risks
  analyzeTask(task: Task, allTasks: Task[]): TaskAnalysis {
    const userTasks = allTasks.filter(t => 
      t.primary === task.primary || t.backup === task.backup
    );

    // Calculate risk score based on various factors
    let riskScore = 0;
    const recommendations: string[] = [];

    // Factor 1: Task status and age
    if (task.status === 'Delayed') {
      riskScore += 40;
      recommendations.push('Immediate attention required - task is delayed');
    } else if (task.status === 'Pending') {
      riskScore += 20;
    }

    // Factor 2: User workload
    const userPendingTasks = userTasks.filter(t => t.status === 'Pending').length;
    if (userPendingTasks > 5) {
      riskScore += 25;
      recommendations.push('High workload detected - consider redistributing tasks');
    }

    // Factor 3: Task frequency and complexity
    if (task.occurrence === '2 hours once') {
      riskScore += 15;
      recommendations.push('High-frequency task - monitor closely');
    }

    // Factor 4: Historical performance
    const userDelayedTasks = userTasks.filter(t => t.status === 'Delayed').length;
    if (userDelayedTasks > 2) {
      riskScore += 20;
      recommendations.push('User has multiple delayed tasks - provide support');
    }

    // Calculate workload balance
    const totalTasks = allTasks.length;
    const userTaskCount = userTasks.length;
    const workloadBalance = Math.max(0, 100 - (userTaskCount / totalTasks * 100 * 5));

    // Predict completion time
    const avgCompletionTime = this.calculateAverageCompletionTime(task.occurrence);
    const predictedCompletion = new Date(Date.now() + avgCompletionTime).toLocaleString();

    return {
      riskScore: Math.min(100, riskScore),
      recommendations,
      predictedCompletion,
      workloadBalance
    };
  }

  // Generate performance metrics for users and overall system
  generatePerformanceMetrics(tasks: Task[], user?: string): PerformanceMetrics {
    const relevantTasks = user 
      ? tasks.filter(t => t.primary === user || t.backup === user)
      : tasks;

    const totalTasks = relevantTasks.length;
    const completedTasks = relevantTasks.filter(t => t.status === 'Done').length;
    const overdueCount = relevantTasks.filter(t => t.status === 'Delayed').length;

    const completionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
    
    // Simulate response time calculation
    const averageResponseTime = this.calculateAverageResponseTime(relevantTasks);
    
    // Calculate efficiency score
    const efficiency = Math.max(0, 100 - (overdueCount / totalTasks * 100));

    // Generate trend data (simulated)
    const dailyTrends = this.generateTrendData(7);
    const weeklyTrends = this.generateTrendData(4);

    return {
      completionRate,
      averageResponseTime,
      overdueCount,
      efficiency,
      trends: {
        daily: dailyTrends,
        weekly: weeklyTrends
      }
    };
  }

  // Generate AI insights and recommendations
  generateInsights(tasks: Task[], users: Record<string, any>): AIInsight[] {
    const insights: AIInsight[] = [];

    // Analyze overall system health
    const overdueTasks = tasks.filter(t => t.status === 'Delayed');
    const pendingTasks = tasks.filter(t => t.status === 'Pending');

    if (overdueTasks.length > tasks.length * 0.2) {
      insights.push({
        type: 'warning',
        title: 'High Overdue Task Rate',
        description: `${overdueTasks.length} tasks are overdue (${Math.round(overdueTasks.length / tasks.length * 100)}%). Consider reviewing workload distribution.`,
        priority: 'high',
        actionable: true
      });
    }

    // Analyze user workload distribution
    const userWorkloads: Record<string, number> = {};
    tasks.forEach(task => {
      userWorkloads[task.primary] = (userWorkloads[task.primary] || 0) + 1;
      userWorkloads[task.backup] = (userWorkloads[task.backup] || 0) + 0.5;
    });

    const workloadValues = Object.values(userWorkloads);
    const avgWorkload = workloadValues.reduce((a, b) => a + b, 0) / workloadValues.length;
    const maxWorkload = Math.max(...workloadValues);

    if (maxWorkload > avgWorkload * 1.5) {
      const overloadedUser = Object.keys(userWorkloads).find(
        user => userWorkloads[user] === maxWorkload
      );
      insights.push({
        type: 'warning',
        title: 'Workload Imbalance Detected',
        description: `${overloadedUser} has significantly higher workload than average. Consider redistributing tasks.`,
        priority: 'medium',
        actionable: true
      });
    }

    // Analyze task completion patterns
    const completionRate = tasks.filter(t => t.status === 'Done').length / tasks.length;
    if (completionRate > 0.9) {
      insights.push({
        type: 'suggestion',
        title: 'Excellent Performance',
        description: `Team is performing exceptionally well with ${Math.round(completionRate * 100)}% completion rate.`,
        priority: 'low',
        actionable: false
      });
    }

    // Suggest optimizations
    const highFrequencyTasks = tasks.filter(t => t.occurrence === '2 hours once');
    if (highFrequencyTasks.length > 5) {
      insights.push({
        type: 'optimization',
        title: 'Consider Task Automation',
        description: `${highFrequencyTasks.length} high-frequency tasks detected. Consider automating repetitive tasks.`,
        priority: 'medium',
        actionable: true
      });
    }

    return insights;
  }

  // Intelligent task scheduling based on workload and patterns
  suggestTaskReassignment(tasks: Task[], users: Record<string, any>): Array<{
    taskId: string;
    currentAssignee: string;
    suggestedAssignee: string;
    reason: string;
  }> {
    const suggestions: Array<{
      taskId: string;
      currentAssignee: string;
      suggestedAssignee: string;
      reason: string;
    }> = [];

    // Calculate current workloads
    const userWorkloads: Record<string, { primary: number; backup: number; delayed: number }> = {};
    
    Object.keys(users).forEach(username => {
      if (users[username].role === 'Agent') {
        userWorkloads[username] = { primary: 0, backup: 0, delayed: 0 };
      }
    });

    tasks.forEach(task => {
      if (userWorkloads[task.primary]) {
        userWorkloads[task.primary].primary++;
        if (task.status === 'Delayed') {
          userWorkloads[task.primary].delayed++;
        }
      }
      if (userWorkloads[task.backup]) {
        userWorkloads[task.backup].backup++;
      }
    });

    // Find overloaded users and suggest reassignments
    Object.entries(userWorkloads).forEach(([username, workload]) => {
      if (workload.primary > 3 && workload.delayed > 1) {
        // Find a user with lighter workload
        const lighterUser = Object.entries(userWorkloads)
          .filter(([user, load]) => user !== username && load.primary < 3)
          .sort((a, b) => a[1].primary - b[1].primary)[0];

        if (lighterUser) {
          const overloadedTasks = tasks.filter(t => 
            t.primary === username && t.status === 'Pending'
          );
          
          if (overloadedTasks.length > 0) {
            suggestions.push({
              taskId: overloadedTasks[0].id,
              currentAssignee: username,
              suggestedAssignee: lighterUser[0],
              reason: `${username} is overloaded with ${workload.primary} primary tasks and ${workload.delayed} delayed tasks`
            });
          }
        }
      }
    });

    return suggestions;
  }

  // Predict task completion time based on historical data
  private calculateAverageCompletionTime(occurrence: string): number {
    const baseTime = {
      '2 hours once': 2 * 60 * 60 * 1000, // 2 hours
      'Daily': 8 * 60 * 60 * 1000, // 8 hours
      'Monthly': 24 * 60 * 60 * 1000 // 24 hours
    };

    return baseTime[occurrence as keyof typeof baseTime] || 4 * 60 * 60 * 1000;
  }

  // Calculate average response time for tasks
  private calculateAverageResponseTime(tasks: Task[]): number {
    const completedTasks = tasks.filter(t => t.status === 'Done' && t.lastUpdated);
    if (completedTasks.length === 0) return 0;

    // Simulate response time calculation (in real app, would use actual timestamps)
    const avgMinutes = 45 + Math.random() * 30; // 45-75 minutes average
    return Math.round(avgMinutes);
  }

  // Generate trend data for charts
  private generateTrendData(points: number): number[] {
    const data: number[] = [];
    let baseValue = 70 + Math.random() * 20; // Start between 70-90

    for (let i = 0; i < points; i++) {
      // Add some realistic variation
      const variation = (Math.random() - 0.5) * 10;
      baseValue = Math.max(0, Math.min(100, baseValue + variation));
      data.push(Math.round(baseValue));
    }

    return data;
  }

  // Generate automated task suggestions based on patterns
  generateTaskSuggestions(tasks: Task[]): Array<{
    type: 'create' | 'modify' | 'merge';
    description: string;
    details: string;
  }> {
    const suggestions: Array<{
      type: 'create' | 'modify' | 'merge';
      description: string;
      details: string;
    }> = [];

    // Analyze task patterns
    const tasksByCategory = tasks.reduce((acc, task) => {
      acc[task.category] = (acc[task.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Suggest new tasks if categories are light
    if (tasksByCategory['Daily'] < 5) {
      suggestions.push({
        type: 'create',
        description: 'Consider adding more daily monitoring tasks',
        details: 'Daily category has fewer tasks than recommended for comprehensive monitoring'
      });
    }

    // Suggest merging similar tasks
    const similarTasks = this.findSimilarTasks(tasks);
    if (similarTasks.length > 0) {
      suggestions.push({
        type: 'merge',
        description: 'Consider merging similar tasks for efficiency',
        details: `Found ${similarTasks.length} pairs of similar tasks that could be combined`
      });
    }

    return suggestions;
  }

  // Find tasks that might be similar and could be merged
  private findSimilarTasks(tasks: Task[]): Array<{ task1: Task; task2: Task; similarity: number }> {
    const similar: Array<{ task1: Task; task2: Task; similarity: number }> = [];

    for (let i = 0; i < tasks.length; i++) {
      for (let j = i + 1; j < tasks.length; j++) {
        const similarity = this.calculateTaskSimilarity(tasks[i], tasks[j]);
        if (similarity > 0.7) {
          similar.push({ task1: tasks[i], task2: tasks[j], similarity });
        }
      }
    }

    return similar;
  }

  // Calculate similarity between two tasks
  private calculateTaskSimilarity(task1: Task, task2: Task): number {
    let similarity = 0;

    // Same occurrence pattern
    if (task1.occurrence === task2.occurrence) similarity += 0.3;

    // Same primary or backup user
    if (task1.primary === task2.primary || task1.backup === task2.backup) similarity += 0.2;

    // Similar titles (basic keyword matching)
    const words1 = task1.title.toLowerCase().split(' ');
    const words2 = task2.title.toLowerCase().split(' ');
    const commonWords = words1.filter(word => words2.includes(word));
    similarity += (commonWords.length / Math.max(words1.length, words2.length)) * 0.5;

    return similarity;
  }
}

export const aiService = AIService.getInstance();