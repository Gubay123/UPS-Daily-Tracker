import { Task, CurrentUser } from '../types';

export interface ReminderSettings {
  emailEnabled: boolean;
  browserNotificationsEnabled: boolean;
  reminderInterval: number; // in minutes
  overdueThreshold: number; // in hours
}

export interface EmailTemplate {
  subject: string;
  body: string;
}

class ReminderService {
  private static instance: ReminderService;
  private reminderInterval: NodeJS.Timeout | null = null;
  private settings: ReminderSettings = {
    emailEnabled: true,
    browserNotificationsEnabled: true,
    reminderInterval: 30, // 30 minutes
    overdueThreshold: 2 // 2 hours
  };

  static getInstance(): ReminderService {
    if (!ReminderService.instance) {
      ReminderService.instance = new ReminderService();
    }
    return ReminderService.instance;
  }

  async requestNotificationPermission(): Promise<boolean> {
    if (!('Notification' in window)) {
      console.warn('Browser does not support notifications');
      return false;
    }

    if (Notification.permission === 'granted') {
      return true;
    }

    if (Notification.permission === 'denied') {
      return false;
    }

    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }

  showBrowserNotification(title: string, body: string, icon?: string): void {
    if (!this.settings.browserNotificationsEnabled) return;
    
    if (Notification.permission === 'granted') {
      const notification = new Notification(title, {
        body,
        icon: icon || '/vite.svg',
        badge: '/vite.svg',
        tag: 'ups-task-reminder',
        requireInteraction: true
      });

      notification.onclick = () => {
        window.focus();
        notification.close();
      };

      // Auto-close after 10 seconds
      setTimeout(() => notification.close(), 10000);
    }
  }

  generateEmailTemplate(tasks: Task[], type: 'overdue' | 'pending' | 'daily_summary'): EmailTemplate {
    const taskList = tasks.map(task => 
      `• ${task.title} (${task.primary}/${task.backup}) - Status: ${task.status}`
    ).join('\n');

    switch (type) {
      case 'overdue':
        return {
          subject: `🚨 UPS Contact Center - Overdue Tasks Alert`,
          body: `Dear Team,

The following tasks are overdue and require immediate attention:

${taskList}

Please update the task status as soon as possible.

Best regards,
UPS Contact Center Task Management System`
        };

      case 'pending':
        return {
          subject: `⏰ UPS Contact Center - Pending Tasks Reminder`,
          body: `Dear Team,

The following tasks are pending and need your attention:

${taskList}

Please review and update accordingly.

Best regards,
UPS Contact Center Task Management System`
        };

      case 'daily_summary':
        return {
          subject: `📊 UPS Contact Center - Daily Task Summary`,
          body: `Dear Team,

Here's your daily task summary:

${taskList}

Have a productive day!

Best regards,
UPS Contact Center Task Management System`
        };

      default:
        return {
          subject: 'UPS Contact Center - Task Reminder',
          body: `Task update required:\n\n${taskList}`
        };
    }
  }

  async sendEmailReminder(to: string[], template: EmailTemplate): Promise<boolean> {
    if (!this.settings.emailEnabled) return false;

    try {
      // In a real application, this would integrate with an email service
      // For demo purposes, we'll simulate the email sending
      console.log('Sending email reminder:', {
        to,
        subject: template.subject,
        body: template.body
      });

      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // For demo, we'll show the email content in a new window
      const emailWindow = window.open('', '_blank', 'width=600,height=400');
      if (emailWindow) {
        emailWindow.document.write(`
          <html>
            <head><title>Email Reminder</title></head>
            <body style="font-family: Arial, sans-serif; padding: 20px;">
              <h3>Email Sent To: ${to.join(', ')}</h3>
              <h4>Subject: ${template.subject}</h4>
              <pre style="white-space: pre-wrap; background: #f5f5f5; padding: 15px; border-radius: 5px;">${template.body}</pre>
              <button onclick="window.close()" style="margin-top: 20px; padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">Close</button>
            </body>
          </html>
        `);
      }

      return true;
    } catch (error) {
      console.error('Failed to send email reminder:', error);
      return false;
    }
  }

  getOverdueTasks(tasks: Task[]): Task[] {
    const now = new Date();
    const thresholdTime = this.settings.overdueThreshold * 60 * 60 * 1000; // Convert hours to milliseconds

    return tasks.filter(task => {
      if (task.status === 'Done') return false;
      
      // If task has never been updated, consider it overdue based on occurrence
      if (!task.lastUpdated) {
        return true; // All unupdated tasks are considered overdue
      }

      const lastUpdate = new Date(task.lastUpdated);
      const timeDiff = now.getTime() - lastUpdate.getTime();
      
      return timeDiff > thresholdTime;
    });
  }

  getPendingTasks(tasks: Task[]): Task[] {
    return tasks.filter(task => task.status === 'Pending');
  }

  getTasksForUser(tasks: Task[], username: string): Task[] {
    return tasks.filter(task => 
      task.primary === username || task.backup === username
    );
  }

  async sendIndividualReminders(tasks: Task[], users: Record<string, any>): Promise<void> {
    const userTasks: Record<string, Task[]> = {};

    // Group tasks by user
    tasks.forEach(task => {
      if (!userTasks[task.primary]) userTasks[task.primary] = [];
      if (!userTasks[task.backup]) userTasks[task.backup] = [];
      
      userTasks[task.primary].push(task);
      userTasks[task.backup].push(task);
    });

    // Send individual reminders
    for (const [username, userTaskList] of Object.entries(userTasks)) {
      if (userTaskList.length === 0) continue;

      const template = this.generateEmailTemplate(userTaskList, 'pending');
      template.subject = `📋 Your Assigned Tasks - ${username}`;
      
      // Browser notification
      this.showBrowserNotification(
        `Tasks Reminder for ${username}`,
        `You have ${userTaskList.length} task(s) requiring attention`
      );

      // Email reminder (in real app, you'd have user email addresses)
      await this.sendEmailReminder([`${username.toLowerCase()}@ups.com`], template);
    }
  }

  async sendBulkReminder(tasks: Task[], type: 'overdue' | 'pending' | 'daily_summary'): Promise<boolean> {
    if (tasks.length === 0) return false;

    const template = this.generateEmailTemplate(tasks, type);
    
    // Get all unique users involved in these tasks
    const involvedUsers = new Set<string>();
    tasks.forEach(task => {
      involvedUsers.add(task.primary);
      involvedUsers.add(task.backup);
    });

    const emailList = Array.from(involvedUsers).map(user => `${user.toLowerCase()}@ups.com`);

    // Browser notification
    this.showBrowserNotification(
      template.subject,
      `${tasks.length} task(s) require attention`
    );

    // Send email
    return await this.sendEmailReminder(emailList, template);
  }

  startAutomaticReminders(tasks: Task[], users: Record<string, any>, onUpdate: () => void): void {
    if (this.reminderInterval) {
      clearInterval(this.reminderInterval);
    }

    this.reminderInterval = setInterval(async () => {
      const overdueTasks = this.getOverdueTasks(tasks);
      const pendingTasks = this.getPendingTasks(tasks);

      if (overdueTasks.length > 0) {
        await this.sendBulkReminder(overdueTasks, 'overdue');
        onUpdate();
      }

      // Send individual reminders for pending tasks every hour
      const now = new Date();
      if (now.getMinutes() === 0) { // Top of every hour
        await this.sendIndividualReminders(pendingTasks, users);
        onUpdate();
      }
    }, this.settings.reminderInterval * 60 * 1000); // Convert minutes to milliseconds
  }

  stopAutomaticReminders(): void {
    if (this.reminderInterval) {
      clearInterval(this.reminderInterval);
      this.reminderInterval = null;
    }
  }

  updateSettings(newSettings: Partial<ReminderSettings>): void {
    this.settings = { ...this.settings, ...newSettings };
  }

  getSettings(): ReminderSettings {
    return { ...this.settings };
  }

  // Schedule daily summary (typically sent at start of shift)
  scheduleDailySummary(tasks: Task[]): void {
    const now = new Date();
    const summaryTime = new Date();
    summaryTime.setHours(18, 30, 0, 0); // 6:30 PM when shift starts

    // If it's past 6:30 PM today, schedule for tomorrow
    if (now > summaryTime) {
      summaryTime.setDate(summaryTime.getDate() + 1);
    }

    const timeUntilSummary = summaryTime.getTime() - now.getTime();

    setTimeout(async () => {
      const allTasks = tasks.filter(task => task.status !== 'Done');
      await this.sendBulkReminder(allTasks, 'daily_summary');
      
      // Schedule next day's summary
      this.scheduleDailySummary(tasks);
    }, timeUntilSummary);
  }
}

export const reminderService = ReminderService.getInstance();