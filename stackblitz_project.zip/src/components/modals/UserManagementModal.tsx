import React, { useState } from 'react';
import { X, UserPlus, Users, Edit, Trash2, Shield, User } from 'lucide-react';

interface UserManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: Record<string, { password: string; role: 'Admin' | 'Agent' }>;
  onAddUser: (username: string, password: string, role: 'Admin' | 'Agent') => void;
  onUpdateUser: (username: string, updates: { password?: string; role?: 'Admin' | 'Agent' }) => void;
  onDeleteUser: (username: string) => void;
}

const UserManagementModal: React.FC<UserManagementModalProps> = ({
  isOpen,
  onClose,
  users,
  onAddUser,
  onUpdateUser,
  onDeleteUser
}) => {
  const [newUser, setNewUser] = useState({
    username: '',
    password: '',
    role: 'Agent' as 'Admin' | 'Agent'
  });
  const [editingUser, setEditingUser] = useState<string | null>(null);
  const [editData, setEditData] = useState({ password: '', role: 'Agent' as 'Admin' | 'Agent' });
  const [error, setError] = useState('');

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newUser.username.trim() || !newUser.password.trim()) {
      setError('Username and password are required');
      return;
    }

    if (users[newUser.username]) {
      setError('Username already exists');
      return;
    }

    if (newUser.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    onAddUser(newUser.username, newUser.password, newUser.role);
    setNewUser({ username: '', password: '', role: 'Agent' });
    setError('');
  };

  const handleEditUser = (username: string) => {
    setEditingUser(username);
    setEditData({
      password: '',
      role: users[username].role
    });
  };

  const handleUpdateUser = () => {
    if (!editingUser) return;

    const updates: { password?: string; role?: 'Admin' | 'Agent' } = {
      role: editData.role
    };

    if (editData.password.trim()) {
      if (editData.password.length < 6) {
        setError('Password must be at least 6 characters');
        return;
      }
      updates.password = editData.password;
    }

    onUpdateUser(editingUser, updates);
    setEditingUser(null);
    setError('');
  };

  const handleDeleteUser = (username: string) => {
    if (confirm(`Are you sure you want to delete user "${username}"?`)) {
      onDeleteUser(username);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Users className="w-6 h-6 text-blue-600 mr-2" />
              <h2 className="text-xl font-bold text-gray-900">User Management</h2>
            </div>
            <button
              onClick={onClose}
              className="p-1 hover:bg-gray-100 rounded-full transition duration-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Add New User */}
            <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <UserPlus className="w-5 h-5 text-blue-600 mr-2" />
                Add New User
              </h3>
              
              <form onSubmit={handleAddUser} className="space-y-4">
                <div>
                  <label htmlFor="newUsername" className="block text-sm font-medium text-gray-700 mb-2">
                    Username
                  </label>
                  <input
                    id="newUsername"
                    type="text"
                    value={newUser.username}
                    onChange={(e) => setNewUser(prev => ({ ...prev, username: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter username"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="newPassword" className="block text-sm font-medium text-gray-700 mb-2">
                    Password
                  </label>
                  <input
                    id="newPassword"
                    type="password"
                    value={newUser.password}
                    onChange={(e) => setNewUser(prev => ({ ...prev, password: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter password"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="newRole" className="block text-sm font-medium text-gray-700 mb-2">
                    Role
                  </label>
                  <select
                    id="newRole"
                    value={newUser.role}
                    onChange={(e) => setNewUser(prev => ({ ...prev, role: e.target.value as 'Admin' | 'Agent' }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="Agent">Agent</option>
                    <option value="Admin">Admin</option>
                  </select>
                </div>

                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-600 px-3 py-2 rounded-lg text-sm">
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition duration-200"
                >
                  Add User
                </button>
              </form>
            </div>

            {/* Existing Users */}
            <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Existing Users</h3>
              
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {Object.entries(users).map(([username, userData]) => (
                  <div key={username} className="bg-white p-4 rounded-lg border border-gray-200">
                    {editingUser === username ? (
                      <div className="space-y-3">
                        <div className="flex items-center space-x-2">
                          <User className="w-4 h-4 text-gray-500" />
                          <span className="font-medium text-gray-900">{username}</span>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            New Password (leave blank to keep current)
                          </label>
                          <input
                            type="password"
                            value={editData.password}
                            onChange={(e) => setEditData(prev => ({ ...prev, password: e.target.value }))}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                            placeholder="Enter new password"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Role
                          </label>
                          <select
                            value={editData.role}
                            onChange={(e) => setEditData(prev => ({ ...prev, role: e.target.value as 'Admin' | 'Agent' }))}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                          >
                            <option value="Agent">Agent</option>
                            <option value="Admin">Admin</option>
                          </select>
                        </div>

                        <div className="flex space-x-2">
                          <button
                            onClick={handleUpdateUser}
                            className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700 transition duration-200"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingUser(null)}
                            className="px-3 py-1 bg-gray-600 text-white rounded text-sm hover:bg-gray-700 transition duration-200"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center space-x-2">
                            {userData.role === 'Admin' ? (
                              <Shield className="w-4 h-4 text-red-500" />
                            ) : (
                              <User className="w-4 h-4 text-blue-500" />
                            )}
                            <span className="font-medium text-gray-900">{username}</span>
                          </div>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            userData.role === 'Admin' 
                              ? 'bg-red-100 text-red-800' 
                              : 'bg-blue-100 text-blue-800'
                          }`}>
                            {userData.role}
                          </span>
                        </div>
                        
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleEditUser(username)}
                            className="p-1 text-blue-600 hover:bg-blue-100 rounded transition duration-200"
                            title="Edit User"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteUser(username)}
                            className="p-1 text-red-600 hover:bg-red-100 rounded transition duration-200"
                            title="Delete User"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-6">
            <button
              onClick={onClose}
              className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition duration-200"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserManagementModal;