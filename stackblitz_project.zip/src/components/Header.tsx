import React from 'react';
import { LogOut, Calendar, UserPlus, Plus, Settings, Bell, BellRing, BarChart3, Users, ListTodo } from 'lucide-react';
import AutoRefreshIndicator from './AutoRefreshIndicator';
import { CurrentUser } from '../types';

interface HeaderProps {
  currentUser: CurrentUser;
  onLogout: () => void;
  onShowCalendar: () => void;
  onAddUser: () => void;
  onAddTask: () => void;
  onManageHolidays: () => void;
  onSendReminders: () => void;
  onReminderSettings: () => void;
  onShowAnalytics: () => void;
  onManageUsers: () => void;
  onManageTasks: () => void;
  isRefreshing: boolean;
  lastUpdate: Date | null;
  autoRefreshEnabled: boolean;
  onToggleAutoRefresh: () => void;
  refreshInterval: number;
}

const Header: React.FC<HeaderProps> = ({
  currentUser,
  onLogout,
  onShowCalendar,
  onAddUser,
  onAddTask,
  onManageHolidays,
  onSendReminders,
  onReminderSettings,
  onShowAnalytics,
  onManageUsers,
  onManageTasks,
  isRefreshing,
  lastUpdate,
  autoRefreshEnabled,
  onToggleAutoRefresh,
  refreshInterval
}) => {
  return (
    <header className="bg-blue-600 text-white shadow-lg">
      <div className="px-6 py-4 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">UPS Contact Center Bangalore</h1>
          <div className="mt-1">
            <AutoRefreshIndicator
              isRefreshing={isRefreshing}
              lastUpdate={lastUpdate}
              isEnabled={autoRefreshEnabled}
              onToggle={onToggleAutoRefresh}
              refreshInterval={refreshInterval}
            />
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <span className="text-blue-100">
            {currentUser.username} ({currentUser.role})
          </span>
          
          <button
            onClick={onShowCalendar}
            className="p-2 hover:bg-blue-700 rounded-lg transition duration-200"
            title="View Tasks by Date"
          >
            <Calendar className="w-5 h-5" />
          </button>

          {currentUser.role === 'Admin' && (
            <>
              <button
                onClick={onShowAnalytics}
                className="px-3 py-2 bg-purple-500 hover:bg-purple-600 rounded-lg text-sm font-medium transition duration-200"
                title="AI Analytics"
              >
                <BarChart3 className="w-4 h-4 inline mr-1" />
                Analytics
              </button>
              
              <button
                onClick={onManageUsers}
                className="px-3 py-2 bg-yellow-500 hover:bg-yellow-600 rounded-lg text-sm font-medium transition duration-200"
                title="Manage Users"
              >
                <Users className="w-4 h-4 inline mr-1" />
                Users
              </button>
              
              <button
                onClick={onManageTasks}
                className="px-3 py-2 bg-green-500 hover:bg-green-600 rounded-lg text-sm font-medium transition duration-200"
                title="Manage Tasks"
              >
                <ListTodo className="w-4 h-4 inline mr-1" />
                Tasks
              </button>
              
              <button
                onClick={onManageHolidays}
                className="px-3 py-2 bg-gray-500 hover:bg-gray-600 rounded-lg text-sm font-medium transition duration-200"
                title="Manage Holidays"
              >
                <Settings className="w-4 h-4 inline mr-1" />
                Holidays
              </button>
              
              <button
                onClick={onSendReminders}
                className="px-3 py-2 bg-cyan-500 hover:bg-cyan-600 rounded-lg text-sm font-medium transition duration-200"
                title="Send Reminders"
              >
                <Bell className="w-4 h-4 inline mr-1" />
                Remind
              </button>
              
              <button
                onClick={onReminderSettings}
                className="px-3 py-2 bg-purple-500 hover:bg-purple-600 rounded-lg text-sm font-medium transition duration-200"
                title="Reminder Settings"
              >
                <BellRing className="w-4 h-4 inline mr-1" />
                Settings
              </button>
            </>
          )}
          
          <button
            onClick={onLogout}
            className="px-3 py-2 bg-red-500 hover:bg-red-600 rounded-lg text-sm font-medium transition duration-200"
          >
            <LogOut className="w-4 h-4 inline mr-1" />
            Logout
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;